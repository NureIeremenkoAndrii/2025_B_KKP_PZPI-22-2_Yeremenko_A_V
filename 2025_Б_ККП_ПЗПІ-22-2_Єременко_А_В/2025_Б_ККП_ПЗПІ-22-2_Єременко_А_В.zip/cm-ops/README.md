# cm-ops
Infrastructure-as-Code repository for deploying and managing Kubernetes clusters and related operational tooling. Includes provisioning scripts, manifests, automation pipelines, and environment configurations.
