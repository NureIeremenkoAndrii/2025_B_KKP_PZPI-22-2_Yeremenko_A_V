# db-gateway
...existing content...

### Http API

...existing content...

#### **Get All Test IDs**

- **Endpoint:** `GET /tests`
- **Description:** Returns all test IDs.
- **Example Request:**
  ```
  curl http://localhost:8080/tests
  ```
- **Response:**
  ```json
  {
    "test_ids": ["test123", "test456", "test789"]
  }
  ```

...existing content...
