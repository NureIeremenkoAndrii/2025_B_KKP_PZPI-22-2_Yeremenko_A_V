package main

import (
	"db-gateway/server"
	"flag"
	"github.com/redis/go-redis/v9"
	"log"
)

func main() {
	var redisAddr string
	flag.StringVar(&redisAddr, "redis-addr", "redis:6379", "Address of the Redis server")
	flag.Parse()

	log.Println("Redis address:", redisAddr)

	rdb := redis.NewClient(&redis.Options{
		Addr: redisAddr,
	})

	go server.StartGRPCServer(rdb)
	go server.StartHTTPServer(rdb)

	log.Println("Both gRPC (50051) and HTTP (8080) servers are running.")
	select {}
}
