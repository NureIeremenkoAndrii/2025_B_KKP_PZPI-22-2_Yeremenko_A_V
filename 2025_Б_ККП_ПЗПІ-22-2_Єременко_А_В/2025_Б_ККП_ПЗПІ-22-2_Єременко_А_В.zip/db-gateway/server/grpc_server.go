package server

import (
	"context"
	"encoding/json"
	"fmt"
	"google.golang.org/grpc/reflection"
	"log"
	"net"
	"strings"

	"github.com/redis/go-redis/v9"
	"google.golang.org/grpc"

	pb "db-gateway/db-gateway/proto/question"
)

type server struct {
	pb.UnimplementedQuestionServiceServer
	redisClient *redis.Client
}

type redisQuestion struct {
	ID       string       `json:"id"`
	Question string       `json:"question"`
	Options  []*pb.Option `json:"options"`
	Tags     []string     `json:"tags"`
	TestID   string       `json:"test_id"`
}

var ctx = context.Background()

func (s *server) SubmitQuestion(ctx context.Context, req *pb.SubmitQuestionRequest) (*pb.SubmitQuestionResponse, error) {
	id := fmt.Sprintf("%d", s.redisClient.Incr(ctx, "global:question_id").Val()) // Ensure unique ID generation
	key := fmt.Sprintf("test:%s:question:%s", req.TestId, id)

	// Assign unique id to each option
	options := make([]*pb.Option, len(req.Options))
	for i, opt := range req.Options {
		options[i] = &pb.Option{
			Id:      fmt.Sprintf("%d", i+1),
			Text:    opt.Text,
			Correct: opt.Correct,
		}
	}

	question := redisQuestion{
		ID:       id,
		Question: req.QuestionText,
		Options:  options,
		Tags:     req.Tags,
		TestID:   req.TestId,
	}

	data, err := json.Marshal(question)
	if err != nil {
		return nil, err
	}

	if err := s.redisClient.Set(ctx, key, data, 0).Err(); err != nil {
		return nil, err
	}

	s.redisClient.SAdd(ctx, fmt.Sprintf("test:%s:questions", req.TestId), id)
	for _, tag := range req.Tags {
		s.redisClient.SAdd(ctx, fmt.Sprintf("test:%s:tags:%s", req.TestId, tag), id)
	}

	return &pb.SubmitQuestionResponse{Status: "ok", QuestionId: id}, nil
}

func (s *server) getQuestion(testID, qid string) (*pb.Question, error) {
	key := fmt.Sprintf("test:%s:question:%s", testID, qid)
	val, err := s.redisClient.Get(ctx, key).Result()
	if err != nil {
		return nil, err
	}

	var rq redisQuestion
	if err := json.Unmarshal([]byte(val), &rq); err != nil {
		return nil, err
	}

	return &pb.Question{
		QuestionId:   qid,
		QuestionText: rq.Question,
		Options:      rq.Options,
		Tags:         rq.Tags,
		TestId:       rq.TestID,
	}, nil
}

func (s *server) GetAllQuestionsByTestId(ctx context.Context, req *pb.TestIdRequest) (*pb.QuestionsResponse, error) {
	ids, err := s.redisClient.SMembers(ctx, fmt.Sprintf("test:%s:questions", req.TestId)).Result()
	if err != nil {
		return nil, err
	}

	var questions []*pb.Question
	for _, id := range ids {
		if q, err := s.getQuestion(req.TestId, id); err == nil {
			questions = append(questions, q)
		}
	}

	return &pb.QuestionsResponse{Questions: questions}, nil
}

func (s *server) GetAllQuestionsByTestIdAndTags(ctx context.Context, req *pb.TestIdAndTagsRequest) (*pb.QuestionsResponse, error) {
	var keys []string
	for _, tag := range req.Tags {
		keys = append(keys, fmt.Sprintf("test:%s:tags:%s", req.TestId, tag))
	}

	ids, err := s.redisClient.SInter(ctx, keys...).Result()
	if err != nil {
		return nil, err
	}

	var questions []*pb.Question
	for _, id := range ids {
		if q, err := s.getQuestion(req.TestId, id); err == nil {
			questions = append(questions, q)
		}
	}

	return &pb.QuestionsResponse{Questions: questions}, nil
}

func (s *server) GetAllQuestions(ctx context.Context, _ *pb.Empty) (*pb.QuestionsResponse, error) {
	keys, err := s.redisClient.Keys(ctx, "test:*:question:*").Result()
	if err != nil {
		return nil, err
	}

	var questions []*pb.Question
	for _, key := range keys {
		parts := strings.Split(key, ":")
		if len(parts) != 4 {
			continue
		}
		testID, qid := parts[1], parts[3]
		if q, err := s.getQuestion(testID, qid); err == nil {
			questions = append(questions, q)
		}
	}

	return &pb.QuestionsResponse{Questions: questions}, nil
}

func (s *server) TestIdExists(ctx context.Context, req *pb.TestIdRequest) (*pb.ExistsResponse, error) {
	exists := s.redisClient.Exists(ctx, fmt.Sprintf("test:%s:questions", req.TestId)).Val() > 0
	return &pb.ExistsResponse{Exists: exists}, nil
}

func StartGRPCServer(rdb *redis.Client) {
	lis, err := net.Listen("tcp", ":50051")
	if err != nil {
		log.Fatalf("Failed to listen: %v", err)
	}

	grpcServer := grpc.NewServer()
	pb.RegisterQuestionServiceServer(grpcServer, &server{redisClient: rdb})
	reflection.Register(grpcServer)

	log.Println("gRPC server listening on port 50051")
	if err := grpcServer.Serve(lis); err != nil {
		log.Fatalf("Failed to serve: %v", err)
	}
}
