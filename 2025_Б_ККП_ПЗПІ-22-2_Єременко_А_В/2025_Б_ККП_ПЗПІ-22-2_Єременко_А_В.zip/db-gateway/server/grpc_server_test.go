package server

import (
	"context"
	"github.com/go-redis/redismock/v9"
	. "github.com/onsi/ginkgo/v2"
	. "github.com/onsi/gomega"

	pb "db-gateway/db-gateway/proto/question"
)

var _ = Describe("gRPC Server", func() {
	var (
		mockRedisClient redismock.ClientMock
		grpcServer      *server
	)

	BeforeEach(func() {
		// Initialize a mock Redis client
		client, mock := redismock.NewClientMock()
		mockRedisClient = mock
		grpcServer = &server{redisClient: client}
	})

	Context("GetAllQuestionsByTestId", func() {
		It("should retrieve all questions for a given test ID", func() {
			mockRedisClient.ExpectSMembers("test:test1:questions").SetVal([]string{"1", "2"})
			mockRedisClient.ExpectGet("test:test1:question:1").SetVal(`{"question":"What is 2+2?","options":[{"id":"1","text":"3","correct":false},{"id":"2","text":"4","correct":true}],"tags":["math"],"test_id":"test1"}`)
			mockRedisClient.ExpectGet("test:test1:question:2").SetVal(`{"question":"What is 3+3?","options":[{"id":"1","text":"5","correct":false},{"id":"2","text":"6","correct":true}],"tags":["math"],"test_id":"test1"}`)

			req := &pb.TestIdRequest{TestId: "test1"}
			resp, err := grpcServer.GetAllQuestionsByTestId(context.Background(), req)
			Expect(err).To(BeNil())
			Expect(resp.Questions).To(HaveLen(2))
			Expect(resp.Questions[0].QuestionText).To(Equal("What is 2+2?"))
			Expect(resp.Questions[1].QuestionText).To(Equal("What is 3+3?"))
		})
	})

	Context("TestIdExists", func() {
		It("should return true if the test ID exists", func() {
			mockRedisClient.ExpectExists("test:test1:questions").SetVal(1)

			req := &pb.TestIdRequest{TestId: "test1"}
			resp, err := grpcServer.TestIdExists(context.Background(), req)
			Expect(err).To(BeNil())
			Expect(resp.Exists).To(BeTrue())
		})

		It("should return false if the test ID does not exist", func() {
			mockRedisClient.ExpectExists("test:nonexistent:questions").SetVal(0)

			req := &pb.TestIdRequest{TestId: "nonexistent"}
			resp, err := grpcServer.TestIdExists(context.Background(), req)
			Expect(err).To(BeNil())
			Expect(resp.Exists).To(BeFalse())
		})
	})
})
