# key-store-service
This service is a lightweight HTTP API written in Go that manages and distributes API keys stored in a Kubernetes ConfigMap. It ensures balanced usage of API keys by always returning the least-used key upon request, and incrementing its usage counter to track usage across the day.

## Features
* Returns the least-used API key via HTTP endpoint
* Tracks usage counts inside a Kubernetes ConfigMap
* Serializes concurrent access using in-memory locking
* Designed for Kubernetes with RBAC, ConfigMap, and service account support
* Deployable via Helm chart


## How it Works
Keys and their usage counts are stored in a ConfigMap.
When a client hits /getkey, the service:
1.	Reads the ConfigMap
2.	Finds the key with the lowest usage count
3.	Returns the key in the response
4.	Increments the count and updates the ConfigMap

## Prerequisites
* Kubernetes cluster
* kubectl command-line tool
* Helm (for deployment)
* Go 1.18 or later (for local development)
* Docker (for containerization)

## API Endpoints
* **GET /getkey**: Returns the least-used API key and increments its usage count.
