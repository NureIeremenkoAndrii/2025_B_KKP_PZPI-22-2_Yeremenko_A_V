package handler

import (
	"context"
	"encoding/json"
	"net/http"
	"sort"
	"strconv"
	"sync"

	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/client-go/kubernetes"
)

type KeyHandlerOptions struct {
	ClientSet     kubernetes.Interface
	Namespace     string
	ConfigMapName string
	Lock          *sync.Mutex
}

func NewKeyHandler(opts KeyHandlerOptions) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		opts.Lock.Lock()
		defer opts.Lock.Unlock()

		ctx := context.Background()
		cm, err := opts.ClientSet.CoreV1().ConfigMaps(opts.Namespace).Get(ctx, opts.ConfigMapName, metav1.GetOptions{})
		if err != nil {
			http.Error(w, "Failed to read configmap: "+err.Error(), http.StatusInternalServerError)
			return
		}

		type KeyValuePair struct {
			Key   string
			Count int
		}

		var all []KeyValuePair
		for k, v := range cm.Data {
			count, err := strconv.Atoi(v)
			if err != nil {
				continue
			}
			all = append(all, KeyValuePair{k, count})
		}

		if len(all) == 0 {
			http.Error(w, "No valid keys", http.StatusInternalServerError)
			return
		}

		sort.Slice(all, func(i, j int) bool {
			return all[i].Count < all[j].Count
		})

		chosen := all[0]
		chosen.Count++
		cm.Data[chosen.Key] = strconv.Itoa(chosen.Count)

		_, err = opts.ClientSet.CoreV1().ConfigMaps(opts.Namespace).Update(ctx, cm, metav1.UpdateOptions{})
		if err != nil {
			http.Error(w, "Failed to update configmap", http.StatusInternalServerError)
			return
		}

		_ = json.NewEncoder(w).Encode(map[string]string{"key": chosen.Key})
	}
}
