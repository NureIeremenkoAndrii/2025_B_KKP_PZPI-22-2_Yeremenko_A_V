package handler

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"

	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/client-go/kubernetes/fake"
)

func TestClearHandler(t *testing.T) {
	// Set up fake client with a pre-populated configmap
	client := fake.NewSimpleClientset(&corev1.ConfigMap{
		ObjectMeta: metav1.ObjectMeta{
			Name:      "test-configmap",
			Namespace: "test-namespace",
		},
		Data: map[string]string{
			"key1": "5",
			"key2": "3",
			"key3": "9",
		},
	})

	// Create request and recorder
	req := httptest.NewRequest(http.MethodPost, "/clear", nil)
	rr := httptest.NewRecorder()

	// Serve the request
	handler := ResetHandler(client, "test-namespace", "test-configmap")
	handler.ServeHTTP(rr, req)

	// Check status
	if rr.Code != http.StatusOK {
		t.Fatalf("expected status 200, got %d", rr.Code)
	}

	// Check response body
	var resp map[string]string
	if err := json.Unmarshal(rr.Body.Bytes(), &resp); err != nil {
		t.Fatalf("invalid response body: %v", err)
	}
	if resp["status"] != "cleared" {
		t.Errorf("expected status=cleared, got %s", resp["status"])
	}

	// Check updated configmap data
	updated, err := client.CoreV1().ConfigMaps("test-namespace").Get(context.Background(), "test-configmap", metav1.GetOptions{})
	if err != nil {
		t.Fatalf("failed to get updated configmap: %v", err)
	}

	for k, v := range updated.Data {
		if v != "0" {
			t.Errorf("expected %s=0, got %s", k, v)
		}
	}
}
