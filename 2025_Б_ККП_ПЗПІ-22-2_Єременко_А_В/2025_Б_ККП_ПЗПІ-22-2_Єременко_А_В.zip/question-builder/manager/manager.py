import requests
import grpc

from proto.question_pb2_grpc import QuestionServiceStub
from proto.question_pb2 import SubmitQuestionRequest, Option


class Manager:
    @staticmethod
    def get_key(key_store_url: str) -> str:
        """
        Retrieves the API key from the key storage service.
        """
        try:
            resp = requests.get(f"{key_store_url}/getkey", timeout=10)
            resp.raise_for_status()
            data = resp.json()
            return data.get("key", "")
        except Exception as e:
            raise RuntimeError(f"Failed to retrieve key from key store: {e}")

    @staticmethod
    def send_question(grpc_url: str, question: dict):
        """
        Sends the question to the storage server via gRPC.
        """
        channel = grpc.insecure_channel(grpc_url)
        stub = QuestionServiceStub(channel)

        # Prepare the request
        options = [Option(text=opt["text"], correct=opt["correct"]) for opt in question["options"]]
        req = SubmitQuestionRequest(
            test_id=question["test_id"],
            question_text=question["question_text"],
            options=options,
            tags=question.get("tags", [])
        )

        response = stub.SubmitQuestion(req)
        if response.status != "ok":
            raise RuntimeError(f"Failed to submit question: {response}")
        return response.question_id

