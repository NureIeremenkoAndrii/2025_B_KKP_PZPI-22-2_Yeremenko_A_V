import json
import re

import openai
from openai.types.chat import ChatCompletionSystemMessageParam, ChatCompletionUserMessageParam

from processor.question import Question
from processor.question_context import QuestionContext


def cleanup_response(response):
    """
    Clean up the AI response to extract the JSON content.
    :param response: The response object from the AI service.
    :return: The cleaned JSON string.
    """
    content = response.choices[0].message.content.strip()

    match = re.search(r"\{.*\}", content, re.DOTALL)
    if not match:
        raise ValueError(f"Could not find JSON in the response.\nRaw response: {content}")

    cleaned = match.group(0)

    return cleaned


class Processor:
    """
    Processor handles generating questions using an AI service.
    """

    def __init__(self, api_key: str, prompt: str, model: str, base_url: str):
        """
        Initialize a new Processor instance.

        Args:
            api_key (str): The API key for the AI service.
            prompt (str): The system prompt used for AI instructions.
            model (str): The specific AI model to be used.
            base_url (str): The base URL for the AI API.
        """
        self.system_prompt = prompt
        self.model = model
        self.client = openai.OpenAI(api_key=api_key, base_url=base_url)

    def generate_question(self, context: QuestionContext) -> Question:
        """
        Generate a multiple-choice question based on the provided context.

        Args:
            context (QuestionContext): The text and mode to generate the question.

        Returns:
            Question: The generated question instance.

        Raises:
            ValueError: If the AI response fails JSON parsing.
        """
        messages = [
            ChatCompletionSystemMessageParam(content=self.system_prompt, role="system"),
            ChatCompletionUserMessageParam(content=context.formatted_prompt(), role="user")
        ]

        response = self.client.chat.completions.create(
            model=self.model,
            messages=messages
        )

        if not response.choices or len(response.choices) == 0:
            raise ValueError("No choices returned from the AI response.")

        try:
            content = cleanup_response(response)
        except ValueError:
            raise ValueError(f"Failed to clean up AI response: {response}")

        try:
            data = json.loads(content)

            return Question(
                question_text=data["question"],
                options=data["options"],
                tags=data.get("tags", [])
            )
        except Exception as e:
            raise ValueError(f"Failed to parse AI response: {e}\nRaw response: {content}")
