package handler

import (
	"encoding/json"
	"fmt"
	"net/http"
	"sync"
	mgr "text-segmenter/manager"
	"text-segmenter/segmenter"
)

type ProcessRequest struct {
	Text   string `json:"text"`
	TestID string `json:"test_id"`
	Window int    `json:"window"`
	Model  string `json:"model"`
}

func ProcessHandler(manager mgr.ManagerInterface) http.HandlerFunc {
	return func(writer http.ResponseWriter, request *http.Request) {
		if request.Method != http.MethodPost {
			http.Error(writer, "Method not allowed", http.StatusMethodNotAllowed)
			return
		}

		var req ProcessRequest
		if err := json.NewDecoder(request.Body).Decode(&req); err != nil {
			http.Error(writer, "Invalid request body", http.StatusBadRequest)
			return
		}

		fmt.Println("Received request with TestID:", req.TestID)

		s := segmenter.NewSegmenter(req.Window)
		segments, err := s.Segment(req.Text)
		if err != nil {
			http.Error(writer, "Segmentation error", http.StatusInternalServerError)
			return
		}

		var wg sync.WaitGroup
		errCh := make(chan error, len(segments))

		for idx, segment := range segments {
			wg.Add(1)
			go func(idx int, segment string) {
				defer wg.Done()
				if err := manager.CreateJobForSegment(req.TestID, segment, idx, req.Model); err != nil {
					errCh <- err
				}
			}(idx, segment)
		}

		wg.Wait()
		close(errCh)

		if len(errCh) > 0 {
			http.Error(writer, "Failed to create one or more k8s jobs", http.StatusInternalServerError)
			for err := range errCh {
				fmt.Println("Error creating job:", err)
			}
			return
		}

		fmt.Println("Segmentation successful for TestID:", req.TestID)

		writer.Header().Set("Content-Type", "application/json")
		writer.WriteHeader(http.StatusOK)
	}
}
