package manager

import (
	"context"
	"fmt"
	batchv1 "k8s.io/api/batch/v1"
	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/client-go/kubernetes"
	"k8s.io/client-go/rest"
)

// ManagerInterface defines the contract for the Manager.
type ManagerInterface interface {
	CreateJobForSegment(testID string, segment string, idx int, model string) error
}

// Manager is responsible for managing Kubernetes jobs.
type Manager struct {
	namespace        string
	imageName        string
	keyStoreUrl      string
	questionStoreUrl string
	retryLimit       int32
	clientSet        *kubernetes.Clientset
}

// NewManager initializes a new Manager with the given namespace.
func NewManager(namespace, imageName string) (*Manager, error) {
	config, err := rest.InClusterConfig()
	if err != nil {
		return nil, fmt.Errorf("failed to get in-cluster config: %w", err)
	}
	client, err := kubernetes.NewForConfig(config)
	if err != nil {
		return nil, fmt.Errorf("failed to create Kubernetes clientSet: %w", err)
	}

	return &Manager{
		namespace: namespace,
		imageName: imageName,
		clientSet: client,
	}, nil
}

func (m *Manager) SetKeyStoreUrl(url string) {
	m.keyStoreUrl = url
}

func (m *Manager) SetQuestionStoreUrl(url string) {
	m.questionStoreUrl = url
}

// CreateJobForSegment creates a Kubernetes Job for processing a text segment.
func (m *Manager) CreateJobForSegment(testID string, segment string, idx int, model string) error {
	jobName := fmt.Sprintf("question-builder-%s-%d", testID, idx)

	job := &batchv1.Job{
		ObjectMeta: metav1.ObjectMeta{
			Name:      jobName,
			Namespace: m.namespace,
		},
		Spec: batchv1.JobSpec{
			BackoffLimit: int32Ptr(m.retryLimit),
			Template: corev1.PodTemplateSpec{
				Spec: corev1.PodSpec{
					RestartPolicy: corev1.RestartPolicyNever,
					Containers: []corev1.Container{
						{
							Name:  "question-builder",
							Image: m.imageName,
							Env: []corev1.EnvVar{
								{Name: "TEST_ID", Value: testID},
								{Name: "INPUT_TEXT", Value: segment},
								{Name: "MODEL", Value: model},
								{Name: "KEY_STORE_URL", Value: m.keyStoreUrl},
								{Name: "QUESTION_STORE_URL", Value: m.questionStoreUrl},
							},
						},
					},
				},
			},
			TTLSecondsAfterFinished: int32Ptr(100),
		},
	}

	_, err := m.clientSet.BatchV1().Jobs(m.namespace).Create(context.Background(), job, metav1.CreateOptions{})
	if err != nil {
		return fmt.Errorf("failed to create job: %w", err)
	}

	return nil
}

// SetRetryLimit sets the retry limit for job execution.
func (m *Manager) SetRetryLimit(i int32) {
	m.retryLimit = i
}

// int32Ptr is a helper function to create a pointer to an int32 value.
func int32Ptr(i int32) *int32 {
	return &i
}
