package segmenter

import "math"

// cosineSim calculates the cosine similarity between two vectors represented as maps.
func cosineSim(a, b map[string]int) float64 {
	var dotProduct, normA, normB float64
	for k, v := range a {
		dotProduct += float64(v * b[k])
		normA += float64(v * v)
	}
	for _, v := range b {
		normB += float64(v * v)
	}
	if normA == 0 || normB == 0 {
		return 0
	}
	return dotProduct / (math.Sqrt(normA) * math.Sqrt(normB))
}

// countTokens counts the occurrences of each token in a slice of strings.
func countTokens(tokens interface{}) map[string]int {
	counts := make(map[string]int)
	if tokenSlice, ok := tokens.([]string); ok {
		for _, token := range tokenSlice {
			counts[token]++
		}
	}
	return counts
}

// addCounts adds the counts from the source map to the destination map.
func addCounts(dst, src map[string]int) {
	for k, v := range src {
		dst[k] += v
	}
}

// findLeftVal finds the first value to the left of the given index where the scores stop decreasing.
func findLeftVal(scores []float64, i int) float64 {
	ptr := i - 1
	for ptr >= 0 && scores[ptr] >= scores[ptr+1] {
		ptr--
	}
	return scores[ptr+1]
}

// findRightVal finds the first value to the right of the given index where the scores stop decreasing.
func findRightVal(scores []float64, i int) float64 {
	ptr := i + 1
	for ptr < len(scores) && scores[ptr] >= scores[ptr-1] {
		ptr++
	}
	return scores[ptr-1]
}

// average calculates the average of a slice of float64 values.
func average(values []float64) float64 {
	sum := 0.0
	for _, v := range values {
		sum += v
	}
	return sum / float64(len(values))
}

// meanAndStdDev calculates the mean and standard deviation of a slice of float64 values.
func meanAndStdDev(values []float64) (float64, float64) {
	mean := average(values)
	var variance float64
	for _, v := range values {
		variance += (v - mean) * (v - mean)
	}
	return mean, math.Sqrt(variance / float64(len(values)))
}
